Place your images here to power the carousels and galleries.
Recommended file names:
- trucking.jpg, courier.jpg, assisted.jpg, parking.jpg for the home carousel.
- trucking1.jpg, trucking2.jpg, trucking3.jpg
- medical-courier1.jpg, medical-courier2.jpg, medical-courier3.jpg
- assisted-living1.jpg, assisted-living2.jpg, assisted-living3.jpg
- truck-parking1.jpg, truck-parking2.jpg, truck-parking3.jpg

Alt text is embedded in HTML for accessibility. Replace as needed to match your images.
Accessibility toolbar: High Contrast, Bigger Text, Underline Links, Colorblind-Safe palette, Reduce Motion.
